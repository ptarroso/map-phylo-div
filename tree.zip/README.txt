This tree is prunned from Pyron et al (2013) Squamata tree.
Only lacertids from Iberia (plus Iberolaceta horvathi) are present in this tree.

References:
Pyron, R. A., Burbrink, F. T., & Wiens, J. J. (2013). A phylogeny and revised 
    classification of Squamata, including 4161 species of lizards and snakes. 
    BMC evolutionary biology, 13(1), 93.

